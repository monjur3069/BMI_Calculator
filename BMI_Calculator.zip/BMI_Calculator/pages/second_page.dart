import 'package:flutter/material.dart';

import '../constants.dart';


class SecondPage extends StatefulWidget {
  static const String routeName = '/second';

  const SecondPage({Key? key}) : super(key: key);

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  late String status;

  @override
  Widget build(BuildContext context) {
    print('build called');
    return Scaffold(
      backgroundColor: colorPrimary,
      appBar: AppBar(
        title: const Text('Second Page'),
        backgroundColor: colorPrimary,
        elevation: 0,//shadow
      ),
      body: Column(
        children: bmiTypeMap.keys
            .map((key) =>
            ListTile(
                  textColor: Colors.white,
                  tileColor: key == status ? Colors.white24 : null,
                  title: Text(key),
                  trailing: Text(bmiTypeMap[key]!),
                ))
            .toList(),
      ),
    );
  }

  @override
  void initState() {
    print('initState called');
    super.initState();
  }

  @override
  void didChangeDependencies() {
    status = ModalRoute.of(context)!.settings.arguments as String;
    print('didChangeDependencies called');
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    print('dispose called');
    super.dispose();
  }
}
